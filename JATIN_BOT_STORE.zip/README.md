# JATIN STORE — Telegram SMM Service Bot

A Python + aiogram 3 Telegram bot with:
- Reply-keyboard main menu (not inline)
- Instagram / YouTube / Facebook / Telegram service categories
- Inline service selection after choosing a platform
- Balance wallet using SQLite
- Manual payment screenshot verification
- FamPay/UPI payment ID + QR image
- Automatic insufficient-balance check
- Order creation and balance deduction
- Admin notifications for deposits and orders
- Admin reply-keyboard panel
- User ban/unban
- Balance approve/reject
- Add/disable/enable services
- Change payment method/ID
- User statistics and recent orders
- Broadcast command

## 1. Install

Python 3.10+ recommended.

```bash
pip install -r requirements.txt
```

## 2. Configure

Set environment variables:

```bash
BOT_TOKEN=YOUR_BOT_TOKEN
ADMIN_IDS=YOUR_TELEGRAM_NUMERIC_ID
```

You can also edit the defaults at the top of `bot.py`.

## 3. Run

```bash
python bot.py
```

## 4. Admin

Send `/admin` from an account whose numeric Telegram ID is in `ADMIN_IDS`.

Important:
- Never publish your BotFather token.
- Payment approval is manual. The bot does not claim to verify a screenshot automatically.
- Replace the bundled `payment_qr.jpg` if you want a different QR.
- The service prices in the database are sample/default values based on the requested list and can be changed by adding/disabling services.

## 5. Default services

Instagram:
- 1K Followers — ₹40
- 2K Followers — ₹75
- 3K Followers — ₹100

YouTube:
- 1K Subscribers — ₹29
- 100K Views — ₹40
- 10K Likes — ₹10
- 1K Views — ₹49

Facebook:
- 1K Followers — ₹50

Telegram starts with no default service so you can add your own from the admin panel.

## 6. Useful admin commands

`/admin` — open admin keyboard

`/users` — recent users

`/broadcast MESSAGE` — broadcast to active users

`/delservice ID` — disable a service

`/onservice ID` — enable a service

## Production notes

For a real deployment, use a VPS or a platform that keeps the process alive and stores the SQLite file persistently. For larger stores, move the database to PostgreSQL and add stronger role/permission controls.

The bot accepts a payment screenshot and sends it to admins for manual approval. Only an admin can approve/reject the deposit, and approval is what credits the user's wallet.
